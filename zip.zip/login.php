<?php
require_once 'common/config.php';
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}
require_once 'common/header.php';
require_once 'common/sidebar.php';
?>

<div class="px-4 py-8 min-h-[80vh] flex flex-col items-center justify-center">
    <div class="w-full max-w-md bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        
        <!-- Tabs -->
        <div class="flex border-b border-gray-200">
            <button id="tab-login" onclick="switchTab('login')" class="flex-1 py-4 text-center font-bold text-orange-600 border-b-2 border-orange-600 transition">Login</button>
            <button id="tab-signup" onclick="switchTab('signup')" class="flex-1 py-4 text-center font-bold text-gray-400 border-b-2 border-transparent transition hover:text-gray-600">Sign Up</button>
        </div>

        <div class="p-6">
            <!-- Login Form -->
            <form id="form-login" onsubmit="handleLogin(event)" class="space-y-4">
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Email</label>
                    <div class="relative">
                        <i class="fa-solid fa-envelope absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <input type="email" name="email" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition" placeholder="you@example.com">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Password</label>
                    <div class="relative">
                        <i class="fa-solid fa-lock absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <input type="password" name="password" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition" placeholder="••••••••">
                    </div>
                </div>
                <div id="login-error" class="text-xs text-red-500 hidden"></div>
                <button type="submit" id="btn-login" class="w-full bg-orange-600 text-white rounded-lg py-3 font-bold shadow-md hover:bg-orange-700 active:bg-orange-800 transition">
                    Login
                </button>
            </form>

            <!-- Signup Form -->
            <form id="form-signup" onsubmit="handleRegister(event)" class="space-y-4 hidden">
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Full Name</label>
                    <div class="relative">
                        <i class="fa-solid fa-user absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <input type="text" name="name" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition" placeholder="John Doe">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Phone Number</label>
                    <div class="relative">
                        <i class="fa-solid fa-phone absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <input type="tel" name="phone" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition" placeholder="000-000-0000">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Email</label>
                    <div class="relative">
                        <i class="fa-solid fa-envelope absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <input type="email" name="email" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition" placeholder="you@example.com">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Password</label>
                    <div class="relative">
                        <i class="fa-solid fa-lock absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <input type="password" name="password" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition" placeholder="Create a password">
                    </div>
                </div>
                <div id="signup-error" class="text-xs text-red-500 hidden"></div>
                <button type="submit" id="btn-signup" class="w-full bg-orange-600 text-white rounded-lg py-3 font-bold shadow-md hover:bg-orange-700 active:bg-orange-800 transition">
                    Create Account
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function switchTab(tab) {
    const btnLogin = document.getElementById('tab-login');
    const btnSignup = document.getElementById('tab-signup');
    const formLogin = document.getElementById('form-login');
    const formSignup = document.getElementById('form-signup');

    if(tab === 'login') {
        btnLogin.className = "flex-1 py-4 text-center font-bold text-orange-600 border-b-2 border-orange-600 transition";
        btnSignup.className = "flex-1 py-4 text-center font-bold text-gray-400 border-b-2 border-transparent transition hover:text-gray-600";
        formLogin.classList.remove('hidden');
        formSignup.classList.add('hidden');
    } else {
        btnSignup.className = "flex-1 py-4 text-center font-bold text-orange-600 border-b-2 border-orange-600 transition";
        btnLogin.className = "flex-1 py-4 text-center font-bold text-gray-400 border-b-2 border-transparent transition hover:text-gray-600";
        formSignup.classList.remove('hidden');
        formLogin.classList.add('hidden');
    }
}

function handleLogin(e) {
    e.preventDefault();
    const btn = document.getElementById('btn-login');
    const err = document.getElementById('login-error');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    err.classList.add('hidden');

    const formData = new FormData(e.target);
    formData.append('action', 'login');

    fetch('ajax_auth.php', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            window.location.href = 'index.php';
        } else {
            err.innerText = data.message;
            err.classList.remove('hidden');
            btn.innerHTML = 'Login';
            btn.disabled = false;
        }
    })
    .catch(() => {
        err.innerText = 'Network Error.';
        err.classList.remove('hidden');
        btn.innerHTML = 'Login';
        btn.disabled = false;
    });
}

function handleRegister(e) {
    e.preventDefault();
    const btn = document.getElementById('btn-signup');
    const err = document.getElementById('signup-error');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    err.classList.add('hidden');

    const formData = new FormData(e.target);
    formData.append('action', 'register');

    fetch('ajax_auth.php', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            window.location.href = 'index.php';
        } else {
            err.innerText = data.message;
            err.classList.remove('hidden');
            btn.innerHTML = 'Create Account';
            btn.disabled = false;
        }
    })
    .catch(() => {
        err.innerText = 'Network Error.';
        err.classList.remove('hidden');
        btn.innerHTML = 'Create Account';
        btn.disabled = false;
    });
}
</script>

<?php require_once 'common/bottom.php'; ?>
