<?php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/sidebar.php';

$cat_id = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$sort = isset($_GET['sort']) ? sanitize_input($_GET['sort']) : 'new';

$query = "SELECT * FROM products";
if ($cat_id > 0) {
    $query .= " WHERE category_id = $cat_id";
}

if ($sort == 'price_low') {
    $query .= " ORDER BY price ASC";
} elseif ($sort == 'price_high') {
    $query .= " ORDER BY price DESC";
} else {
    $query .= " ORDER BY id DESC"; // new
}

$products = $conn->query($query);
?>

<div class="px-4 py-4 min-h-screen">
    <!-- Filters -->
    <div class="flex items-center justify-between mb-4 bg-white p-3 rounded-xl shadow-sm border border-gray-100">
        <div class="text-sm font-semibold text-gray-800">
            <?php echo $products->num_rows; ?> Products
        </div>
        <div class="flex items-center gap-2">
            <i class="fa-solid fa-filter text-gray-400"></i>
            <select id="sortOption" onchange="sortData()" class="bg-transparent text-sm text-gray-600 focus:outline-none">
                <option value="new" <?php echo $sort == 'new' ? 'selected' : ''; ?>>Newest First</option>
                <option value="price_low" <?php echo $sort == 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                <option value="price_high" <?php echo $sort == 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
            </select>
        </div>
    </div>

    <!-- Product Grid -->
    <div class="grid grid-cols-2 gap-3 mb-6">
        <?php if($products && $products->num_rows > 0): ?>
            <?php while($prod = $products->fetch_assoc()): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col relative w-full touch-manipulation pb-1">
                <a href="product_detail.php?id=<?php echo $prod['id']; ?>" class="block pt-2">
                    <div class="w-full h-32 flex items-center justify-center p-2">
                        <img src="uploads/<?php echo $prod['image'] ?: 'default.png'; ?>" alt="<?php echo $prod['name']; ?>" class="max-h-full max-w-full object-contain" onerror="this.src='https://via.placeholder.com/150?text=Product'">
                    </div>
                </a>
                <div class="p-3 pt-1 flex-1 flex flex-col">
                    <a href="product_detail.php?id=<?php echo $prod['id']; ?>" class="block">
                        <h4 class="text-xs text-gray-800 font-semibold line-clamp-2 leading-tight mb-1"><?php echo $prod['name']; ?></h4>
                    </a>
                    <div class="mt-auto flex items-center justify-between">
                        <span class="text-orange-600 font-bold text-sm">$<?php echo $prod['price']; ?></span>
                        <button onclick="addToCart(<?php echo $prod['id']; ?>)" class="bg-orange-50 text-orange-600 w-7 h-7 rounded-full flex items-center justify-center active:bg-orange-200 transition">
                            <i class="fa-solid fa-plus text-xs"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-span-2 text-center py-10">
                <i class="fa-solid fa-box-open text-4xl text-gray-300 mb-3"></i>
                <p class="text-sm text-gray-500">No products found in this category.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function sortData() {
    const sortVal = document.getElementById('sortOption').value;
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('sort', sortVal);
    window.location.href = 'product.php?' + urlParams.toString();
}

function addToCart(productId) {
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', productId);
    formData.append('qty', 1);

    fetch('ajax_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            alert('Added to cart!');
            location.reload();
        }
    });
}
</script>

<?php require_once 'common/bottom.php'; ?>
