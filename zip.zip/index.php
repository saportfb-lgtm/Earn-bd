<?php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/sidebar.php';

// Fetch categories
$cat_query = "SELECT * FROM categories ORDER BY name ASC";
$categories = $conn->query($cat_query);

// Fetch featured products
$prod_query = "SELECT * FROM products ORDER BY id DESC LIMIT 10";
$products = $conn->query($prod_query);
?>

<div class="px-4 py-4">
    <!-- Promotional Banner Carousel (Static for now) -->
    <div class="w-full h-40 bg-orange-100 rounded-xl mb-6 relative overflow-hidden flex items-center justify-center">
        <div class="absolute inset-0 bg-gradient-to-r from-orange-500 to-orange-400 opacity-90"></div>
        <div class="z-10 text-white text-center px-4">
            <h2 class="text-2xl font-bold mb-1">Big Sale!</h2>
            <p class="text-sm opacity-90">Up to 50% off on Electronics.</p>
            <button class="mt-3 bg-white text-orange-600 px-4 py-1.5 rounded-full text-xs font-bold shadow-md">Shop Now</button>
        </div>
    </div>

    <!-- Categories Horizontal Scroll -->
    <div class="mb-6">
        <div class="flex justify-between items-center mb-3">
            <h3 class="text-lg font-bold text-gray-800">Top Categories</h3>
            <a href="product.php" class="text-sm text-orange-600 font-medium">See All</a>
        </div>
        <div class="flex overflow-x-auto hide-scrollbar gap-4 pb-2">
            <?php if($categories && $categories->num_rows > 0): ?>
                <?php while($cat = $categories->fetch_assoc()): ?>
                <a href="product.php?cat=<?php echo $cat['id']; ?>" class="flex flex-col items-center flex-shrink-0 w-20">
                    <div class="w-14 h-14 bg-white rounded-full shadow-sm flex items-center justify-center p-2 mb-2 border border-gray-100">
                        <img src="uploads/<?php echo $cat['image'] ?: 'default.png'; ?>" alt="<?php echo $cat['name']; ?>" class="w-full h-full object-contain" onerror="this.src='https://via.placeholder.com/50?text=Icon'">
                    </div>
                    <span class="text-xs text-gray-700 text-center font-medium line-clamp-1 w-full"><?php echo $cat['name']; ?></span>
                </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-xs text-gray-500">No categories found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Featured Products Grid -->
    <div class="mb-6">
        <h3 class="text-lg font-bold text-gray-800 mb-3">Featured Products</h3>
        <div class="grid grid-cols-2 gap-3">
            <?php if($products && $products->num_rows > 0): ?>
                <?php while($prod = $products->fetch_assoc()): ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col relative w-full touch-manipulation pb-1">
                    <a href="product_detail.php?id=<?php echo $prod['id']; ?>" class="block pt-2">
                        <div class="w-full h-32 flex items-center justify-center p-2">
                            <img src="uploads/<?php echo $prod['image'] ?: 'default.png'; ?>" alt="<?php echo $prod['name']; ?>" class="max-h-full max-w-full object-contain" onerror="this.src='https://via.placeholder.com/150?text=Product'">
                        </div>
                    </a>
                    <div class="p-3 pt-1 flex-1 flex flex-col">
                        <a href="product_detail.php?id=<?php echo $prod['id']; ?>" class="block">
                            <h4 class="text-xs text-gray-800 font-semibold line-clamp-2 leading-tight mb-1"><?php echo $prod['name']; ?></h4>
                        </a>
                        <div class="mt-auto flex items-center justify-between">
                            <span class="text-orange-600 font-bold text-sm">$<?php echo $prod['price']; ?></span>
                            <button onclick="addToCart(<?php echo $prod['id']; ?>)" class="bg-orange-50 text-orange-600 w-7 h-7 rounded-full flex items-center justify-center active:bg-orange-200 transition">
                                <i class="fa-solid fa-plus text-xs"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-xs text-gray-500">No products found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function addToCart(productId) {
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', productId);
    formData.append('qty', 1);

    fetch('ajax_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            // Briefly show notification (toast logic)
            alert('Added to cart!');
            location.reload(); // Quick refresh to update badge, or we can update DOM
        }
    });
}
</script>

<?php require_once 'common/bottom.php'; ?>
