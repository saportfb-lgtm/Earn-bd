<?php
require_once 'common/config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}

if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

// Fetch user info for autofill
$stmt = $conn->prepare("SELECT name, phone, address FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Calculate total
$total = 0;
$ids = implode(',', array_keys($_SESSION['cart']));
$res = $conn->query("SELECT id, price FROM products WHERE id IN ($ids)");
while($row = $res->fetch_assoc()) {
    $total += $row['price'] * $_SESSION['cart'][$row['id']];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize_input($_POST['name']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    
    // Create order
    $ostmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, status, name, phone, address, payment_method) VALUES (?, ?, 'Placed', ?, ?, ?, 'COD')");
    $ostmt->bind_param("idsss", $_SESSION['user_id'], $total, $name, $phone, $address);
    if($ostmt->execute()) {
        $order_id = $ostmt->insert_id;
        
        // Insert items
        $i_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        
        $res = $conn->query("SELECT id, price FROM products WHERE id IN ($ids)");
        while($row = $res->fetch_assoc()) {
            $pid = $row['id'];
            $qty = $_SESSION['cart'][$pid];
            $price = $row['price'];
            $i_stmt->bind_param("iiid", $order_id, $pid, $qty, $price);
            $i_stmt->execute();
        }
        
        // Clear cart
        unset($_SESSION['cart']);
        header("Location: order.php");
        exit;
    } else {
        $error = "Failed to place order.";
    }
}

require_once 'common/header.php';
require_once 'common/sidebar.php';
?>

<div class="px-4 py-6 min-h-[80vh] flex flex-col">
    <!-- Back Button -->
    <div class="flex items-center mb-6">
        <button onclick="history.back()" class="mr-4 text-gray-600">
            <i class="fa-solid fa-arrow-left text-xl"></i>
        </button>
        <h2 class="text-xl font-bold text-gray-800">Checkout</h2>
    </div>

    <?php if(isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <form method="POST" action="checkout.php" class="flex-1 flex flex-col">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-4">
            <h3 class="text-md font-bold text-gray-800 mb-4 border-b pb-2">Delivery Address</h3>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-wider">Full Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-wider">Phone Number</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-wider">Full Address</label>
                    <textarea name="address" rows="3" required class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500"><?php echo htmlspecialchars($user['address']); ?></textarea>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-4">
            <h3 class="text-md font-bold text-gray-800 mb-3 border-b pb-2">Payment Method</h3>
            <div class="flex items-center gap-3 p-3 border border-orange-200 bg-orange-50 rounded-lg">
                <input type="radio" checked readonly class="text-orange-600 focus:ring-orange-500">
                <span class="text-sm font-semibold text-gray-800">Cash on Delivery (COD)</span>
                <i class="fa-solid fa-money-bill-wave text-green-600 ml-auto"></i>
            </div>
        </div>

        <div class="mt-auto bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <div class="flex justify-between items-center mb-2">
                <span class="text-sm text-gray-600">Total Amount</span>
                <span class="font-bold text-orange-600 text-lg">$<?php echo number_format($total, 2); ?></span>
            </div>
            <button type="submit" class="w-full bg-orange-600 text-white rounded-xl py-3 font-bold shadow-md active:bg-orange-700 mt-2">Place Order</button>
        </div>
    </form>
</div>

<?php require_once 'common/bottom.php'; ?>
