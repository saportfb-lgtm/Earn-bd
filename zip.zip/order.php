<?php
require_once 'common/config.php';
if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}

require_once 'common/header.php';
require_once 'common/sidebar.php';

$user_id = $_SESSION['user_id'];

// Fetch orders
$query = "SELECT id, total_amount, status, created_at FROM orders WHERE user_id = ? ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders_result = $stmt->get_result();

$active_orders = [];
$history_orders = [];

while($order = $orders_result->fetch_assoc()) {
    // Fetch one item for cover image
    $item_query = "SELECT p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ".$order['id']." LIMIT 1";
    $item_res = $conn->query($item_query);
    $cover = $item_res->fetch_assoc();
    
    // Count total items
    $count_query = "SELECT SUM(quantity) as items_count FROM order_items WHERE order_id = ".$order['id'];
    $count_res = $conn->query($count_query);
    $items_count = $count_res->fetch_assoc()['items_count'];

    $order['cover_name'] = $cover ? $cover['name'] : 'Unknown Product';
    $order['cover_image'] = $cover ? $cover['image'] : 'default.png';
    $order['items_count'] = $items_count;

    if (in_array($order['status'], ['Placed', 'Dispatched'])) {
        $active_orders[] = $order;
    } else {
        $history_orders[] = $order;
    }
}
?>

<div class="px-4 py-4 min-h-screen">
    <h2 class="text-xl font-bold text-gray-800 mb-4">My Orders</h2>

    <!-- Two Tab Layout -->
    <div class="flex bg-white rounded-xl p-1 mb-5 shadow-sm border border-gray-100">
        <button onclick="switchOrderTab('active')" id="tab-btn-active" class="flex-1 py-1.5 text-sm font-bold text-white bg-orange-600 rounded-lg shadow-sm transition">Active Orders</button>
        <button onclick="switchOrderTab('history')" id="tab-btn-history" class="flex-1 py-1.5 text-sm font-bold text-gray-500 hover:text-gray-800 transition">History</button>
    </div>

    <!-- Active Orders Tab -->
    <div id="tab-active" class="space-y-4">
        <?php if(empty($active_orders)): ?>
            <div class="text-center py-10">
                <i class="fa-solid fa-box-open text-4xl text-gray-300 mb-3"></i>
                <p class="text-sm text-gray-500">No active orders right now.</p>
            </div>
        <?php else: ?>
            <?php foreach($active_orders as $o): ?>
                <?php renderOrderCard($o); ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- History Tab -->
    <div id="tab-history" class="space-y-4 hidden">
        <?php if(empty($history_orders)): ?>
            <div class="text-center py-10">
                <i class="fa-solid fa-history text-4xl text-gray-300 mb-3"></i>
                <p class="text-sm text-gray-500">No previous orders found.</p>
            </div>
        <?php else: ?>
            <?php foreach($history_orders as $o): ?>
                <?php renderOrderCard($o); ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php 
function renderOrderCard($o) { 
    $statusColors = [
        'Placed' => 'text-blue-600 bg-blue-50',
        'Dispatched' => 'text-orange-600 bg-orange-50',
        'Delivered' => 'text-green-600 bg-green-50',
        'Cancelled' => 'text-red-600 bg-red-50'
    ];
    $colorClass = $statusColors[$o['status']];
    $date = date("d M Y", strtotime($o['created_at']));
?>
<div class="bg-white rounded-xl shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-gray-100 overflow-hidden">
    <!-- Header -->
    <div class="flex justify-between items-center px-4 py-3 border-b border-gray-50 bg-gray-50/50">
        <div class="flex flex-col">
            <span class="text-xs text-gray-500 font-medium">Order ID #<?php echo $o['id']; ?></span>
            <span class="text-xs text-gray-400"><?php echo $date; ?></span>
        </div>
        <span class="px-2.5 py-1 rounded-sm text-[10px] font-bold uppercase tracking-wide <?php echo $colorClass; ?>">
            <?php echo $o['status']; ?>
        </span>
    </div>

    <!-- Content -->
    <div class="p-4 flex gap-3 items-center">
        <div class="w-16 h-16 bg-gray-50 rounded-lg flex items-center justify-center p-1 border border-gray-100 shrink-0">
            <img src="uploads/<?php echo $o['cover_image']; ?>" onerror="this.src='https://via.placeholder.com/80?text=Item'" class="max-w-full max-h-full object-contain">
        </div>
        <div class="flex-1 min-w-0">
            <h4 class="text-sm font-bold text-gray-800 line-clamp-1 mb-1"><?php echo $o['cover_name']; ?></h4>
            <p class="text-xs text-gray-500 mb-1">
                <?php echo $o['items_count']; ?> item(s) in this order
            </p>
            <p class="text-sm font-bold text-gray-900">$<?php echo number_format($o['total_amount'], 2); ?></p>
        </div>
    </div>

    <!-- Progress Tracker (only for Active) -->
    <?php if(in_array($o['status'], ['Placed', 'Dispatched', 'Delivered'])): ?>
    <?php 
        $st = $o['status'];
        $s1 = 'text-green-600'; $l1 = 'bg-green-600';
        $s2 = ($st=='Dispatched'||$st=='Delivered')?'text-green-600':'text-gray-300';
        $l2 = ($st=='Delivered')?'bg-green-600':'bg-gray-200';
        $s3 = ($st=='Delivered')?'text-green-600':'text-gray-300';
    ?>
    <div class="px-6 py-3 bg-white border-t border-gray-50">
        <div class="flex items-center justify-between relative">
            <div class="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 flex">
                <div class="w-1/2 h-full <?php echo $l1; ?>"></div>
                <div class="w-1/2 h-full <?php echo $l2; ?>"></div>
            </div>
            
            <div class="z-10 flex flex-col items-center bg-white px-2">
                <i class="fa-solid fa-check-circle <?php echo $s1; ?> text-lg mb-1"></i>
                <span class="text-[10px] font-semibold text-gray-600">Placed</span>
            </div>
            <div class="z-10 flex flex-col items-center bg-white px-2">
                <i class="fa-solid fa-truck <?php echo $s2; ?> text-lg mb-1"></i>
                <span class="text-[10px] font-semibold text-gray-600">Dispatched</span>
            </div>
            <div class="z-10 flex flex-col items-center bg-white px-2">
                <i class="fa-solid fa-box-open <?php echo $s3; ?> text-lg mb-1"></i>
                <span class="text-[10px] font-semibold text-gray-600">Delivered</span>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php } ?>

<script>
function switchOrderTab(tab) {
    const actBtn = document.getElementById('tab-btn-active');
    const histBtn = document.getElementById('tab-btn-history');
    const actTab = document.getElementById('tab-active');
    const histTab = document.getElementById('tab-history');

    if(tab === 'active') {
        actBtn.className = "flex-1 py-1.5 text-sm font-bold text-white bg-orange-600 rounded-lg shadow-sm transition";
        histBtn.className = "flex-1 py-1.5 text-sm font-bold text-gray-500 hover:text-gray-800 transition";
        actTab.classList.remove('hidden');
        histTab.classList.add('hidden');
    } else {
        histBtn.className = "flex-1 py-1.5 text-sm font-bold text-white bg-orange-600 rounded-lg shadow-sm transition";
        actBtn.className = "flex-1 py-1.5 text-sm font-bold text-gray-500 hover:text-gray-800 transition";
        histTab.classList.remove('hidden');
        actTab.classList.add('hidden');
    }
}
</script>

<?php require_once 'common/bottom.php'; ?>
