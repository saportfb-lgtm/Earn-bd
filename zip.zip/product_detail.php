<?php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/sidebar.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id == 0) {
    die("Product not found");
}

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$prod = $stmt->get_result()->fetch_assoc();

if (!$prod) {
    die("Product not found");
}

// Fetch related
$rel_query = "SELECT * FROM products WHERE category_id = ".$prod['category_id']." AND id != $id LIMIT 4";
$related = $conn->query($rel_query);
?>

<div class="pb-24">
    <!-- Back Button -->
    <button onclick="history.back()" class="fixed top-4 left-4 z-50 bg-white/80 backdrop-blur w-10 h-10 rounded-full flex items-center justify-center shadow-md">
        <i class="fa-solid fa-arrow-left text-gray-700"></i>
    </button>
    
    <!-- Image Slider Area (Basic) -->
    <div class="w-full bg-white pt-10 pb-4 h-72 flex justify-center items-center relative shadow-sm">
        <img src="uploads/<?php echo $prod['image'] ?: 'default.png'; ?>" onerror="this.src='https://via.placeholder.com/300?text=Product+Image'" class="max-w-full max-h-full object-contain px-8">
        <!-- Pagination Dots mock -->
        <div class="absolute bottom-4 flex gap-1.5">
            <div class="w-2 h-2 rounded-full bg-orange-600"></div>
            <div class="w-2 h-2 rounded-full bg-gray-300"></div>
            <div class="w-2 h-2 rounded-full bg-gray-300"></div>
        </div>
    </div>

    <!-- Details -->
    <div class="px-4 py-5 bg-white mb-2 rounded-b-3xl shadow-sm border-b border-gray-100">
        <div class="flex justify-between items-start mb-2">
            <h1 class="text-xl font-bold text-gray-800 leading-tight pr-4"><?php echo $prod['name']; ?></h1>
            <button class="text-gray-400 hover:text-red-500"><i class="fa-regular fa-heart text-xl"></i></button>
        </div>
        <div class="mb-4">
            <span class="text-2xl font-bold text-orange-600">$<?php echo $prod['price']; ?></span>
            <span class="text-sm line-through text-gray-400 ml-2">$<?php echo number_format($prod['price'] * 1.2, 2); ?></span> <!-- Mock MRP -->
        </div>
        
        <?php if($prod['stock'] > 0): ?>
            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-green-50 text-green-600 text-xs font-semibold mb-4">
                <div class="w-1.5 h-1.5 rounded-full bg-green-500"></div> In Stock
            </span>
        <?php else: ?>
            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-50 text-red-600 text-xs font-semibold mb-4">
                <div class="w-1.5 h-1.5 rounded-full bg-red-500"></div> Out of Stock
            </span>
        <?php endif; ?>

        <h3 class="text-sm font-bold text-gray-800 mb-2">Description</h3>
        <p class="text-sm text-gray-600 leading-relaxed">
            <?php echo nl2br(htmlspecialchars($prod['description'])); ?>
        </p>
    </div>

    <!-- Related Products -->
    <?php if($related && $related->num_rows > 0): ?>
    <div class="px-4 py-4">
        <h3 class="text-lg font-bold text-gray-800 mb-3">Similar Products</h3>
        <div class="flex overflow-x-auto hide-scrollbar gap-3 pb-2">
            <?php while($rel = $related->fetch_assoc()): ?>
            <a href="product_detail.php?id=<?php echo $rel['id']; ?>" class="flex-shrink-0 w-32 bg-white rounded-xl shadow-sm border border-gray-100 p-2">
                <div class="w-full h-24 flex items-center justify-center mb-2">
                    <img src="uploads/<?php echo $rel['image'] ?: 'default.png'; ?>" class="max-h-full max-w-full object-contain" onerror="this.src='https://via.placeholder.com/150?text=Product'">
                </div>
                <h4 class="text-xs font-semibold text-gray-800 line-clamp-2 mb-1"><?php echo $rel['name']; ?></h4>
                <span class="text-orange-600 font-bold text-sm">$<?php echo $rel['price']; ?></span>
            </a>
            <?php endwhile; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Sticky Bottom Add to Cart Bar -->
<div class="fixed bottom-0 w-full bg-white border-t p-3 pb-safe shadow-[0_-5px_15px_rgba(0,0,0,0.05)] z-40">
    <div class="flex items-center gap-3">
        <!-- Qty selector -->
        <div class="flex items-center bg-gray-100 rounded-lg p-1">
            <button onclick="changeQty(-1)" class="w-10 h-10 flex items-center justify-center text-gray-600 font-bold active:bg-gray-200 rounded-md">-</button>
            <input type="text" id="detailQty" value="1" readonly class="w-10 text-center bg-transparent font-bold focus:outline-none text-gray-800">
            <button onclick="changeQty(1)" class="w-10 h-10 flex items-center justify-center text-gray-600 font-bold active:bg-gray-200 rounded-md">+</button>
        </div>
        <!-- Add to cart -->
        <button onclick="addCurrentToCart()" class="flex-1 bg-orange-600 text-white py-3.5 rounded-xl font-bold shadow-md lg:shadow-none hover:bg-orange-700 active:bg-orange-800 transition">
            <i class="fa-solid fa-shopping-bag mr-2"></i> Add to Cart
        </button>
    </div>
</div>

<script>
function changeQty(am) {
    let q = document.getElementById('detailQty');
    let v = parseInt(q.value) + am;
    if(v < 1) v = 1;
    q.value = v;
}

function addCurrentToCart() {
    <?php if($prod['stock'] <= 0): ?>
        alert('Product is out of stock!');
        return;
    <?php endif; ?>

    const qty = document.getElementById('detailQty').value;
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', <?php echo $prod['id']; ?>);
    formData.append('qty', qty);

    let btn = document.querySelector('button[onclick="addCurrentToCart()"]');
    let oldHTML = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Adding...';
    
    fetch('ajax_cart.php', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            btn.innerHTML = '<i class="fa-solid fa-check mr-2"></i> Added';
            setTimeout(() => { btn.innerHTML = oldHTML; }, 2000);
            alert('Added to cart!'); // Usually use a toast here
        }
    });
}
</script>

<!-- Using custom bottom nav behavior since this page has sticky add to cart -->
<style>
    .pb-safe { padding-bottom: env(safe-area-inset-bottom); }
    /* Hide the common bottom nav on this specific page to replace with sticky bar */
    nav.fixed.bottom-0.z-30 { display: none !important; }
</style>
</body>
</html>
