<?php
require_once 'common/config.php';
if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize_input($_POST['name']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    
    $stmt = $conn->prepare("UPDATE users SET name=?, phone=?, address=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $phone, $address, $user_id);
    if($stmt->execute()) {
        $msg = "Profile updated successfully!";
        $_SESSION['user_name'] = $name;
    }
}

$stmt = $conn->prepare("SELECT name, email, phone, address FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

require_once 'common/header.php';
require_once 'common/sidebar.php';
?>

<div class="px-4 py-6 min-h-[80vh] flex flex-col">
    <h2 class="text-xl font-bold text-gray-800 mb-6">My Profile</h2>

    <!-- Profile Header -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col items-center justify-center mb-6">
        <div class="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 mb-3 border-4 border-white shadow-md">
            <i class="fa-solid fa-user text-3xl"></i>
        </div>
        <h3 class="text-lg font-bold text-gray-800"><?php echo htmlspecialchars($user['name']); ?></h3>
        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($user['email']); ?></p>
    </div>

    <?php if($msg): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4 text-sm" role="alert">
            <span class="block sm:inline"><?php echo $msg; ?></span>
        </div>
    <?php endif; ?>

    <!-- Edit Profile Form -->
    <form method="POST" action="profile.php" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 space-y-4 mb-6">
        <h4 class="font-bold text-gray-800 border-b pb-2 mb-2">Personal Information</h4>
        
        <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Full Name</label>
            <div class="relative">
                <i class="fa-solid fa-user absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition">
            </div>
        </div>
        
        <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Phone Number</label>
            <div class="relative">
                <i class="fa-solid fa-phone absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition">
            </div>
        </div>
        
        <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Address</label>
            <textarea name="address" rows="3" class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition"><?php echo htmlspecialchars($user['address']); ?></textarea>
        </div>

        <button type="submit" class="w-full bg-gray-900 text-white rounded-lg py-3 font-bold shadow-md hover:bg-black active:scale-[0.98] transition">
            Save Changes
        </button>
    </form>

    <!-- Logout Button -->
    <button onclick="logoutUser()" class="w-full bg-red-50 text-red-600 border border-red-200 rounded-xl py-3 font-bold flex items-center justify-center gap-2 active:bg-red-100 transition">
        <i class="fa-solid fa-sign-out-alt"></i> Logout
    </button>
</div>

<script>
// logoutUser is already defined in sidebar.php, so can just call it
</script>

<?php require_once 'common/bottom.php'; ?>
