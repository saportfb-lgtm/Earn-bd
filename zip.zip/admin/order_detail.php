<?php
require_once '../common/config.php';
session_start();
if (!is_admin()) { header("Location: login.php"); exit; }

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id == 0) die("Invalid order");

$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if(!$order) die("Order not found");

$items_query = "SELECT oi.*, p.name, p.image FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = $id";
$items = $conn->query($items_query);

require_once 'common/header.php';
require_once 'common/sidebar.php';
?>

<div class="px-4 py-6 md:px-8">
    <div class="flex items-center mb-6">
        <button onclick="history.back()" class="mr-4 text-gray-500 hover:text-gray-800 transition">
            <i class="fa-solid fa-arrow-left text-xl"></i>
        </button>
        <h1 class="text-2xl font-bold text-gray-800">Order #<?php echo $order['id']; ?></h1>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Order info -->
        <div class="lg:col-span-2 space-y-6">
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-bold text-gray-800 mb-4 border-b pb-2">Items</h3>
                <div class="space-y-4">
                    <?php while($item = $items->fetch_assoc()): ?>
                    <div class="flex items-center gap-4">
                        <img src="../uploads/<?php echo $item['image']; ?>" onerror="this.src='https://via.placeholder.com/60'" class="w-16 h-16 rounded object-cover shadow-sm bg-gray-50 border border-gray-100">
                        <div class="flex-1">
                            <h4 class="text-sm font-semibold text-gray-800"><?php echo $item['name']; ?></h4>
                            <p class="text-xs text-gray-500">Qty: <?php echo $item['quantity']; ?> × $<?php echo $item['price']; ?></p>
                        </div>
                        <span class="font-bold text-gray-900">$<?php echo number_format($item['quantity'] * $item['price'], 2); ?></span>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>

        <div class="space-y-6">
            <!-- Update Status -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-bold text-gray-800 mb-4 border-b pb-2">Order Status</h3>
                <select id="statusSelect" class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-gray-800 mb-4">
                    <option value="Placed" <?php echo $order['status']=='Placed'?'selected':''; ?>>Placed</option>
                    <option value="Dispatched" <?php echo $order['status']=='Dispatched'?'selected':''; ?>>Dispatched</option>
                    <option value="Delivered" <?php echo $order['status']=='Delivered'?'selected':''; ?>>Delivered</option>
                    <option value="Cancelled" <?php echo $order['status']=='Cancelled'?'selected':''; ?>>Cancelled</option>
                </select>
                <button onclick="updateStatus()" class="w-full bg-gray-900 text-white rounded-lg py-2 text-sm font-bold shadow hover:bg-black transition">Update</button>
            </div>

            <!-- Customer Info -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-bold text-gray-800 mb-4 border-b pb-2">Customer & Delivery</h3>
                <p class="text-sm text-gray-800 font-semibold mb-1"><?php echo $order['name']; ?></p>
                <p class="text-xs text-gray-500 mb-3"><i class="fa-solid fa-phone mr-1"></i> <?php echo $order['phone']; ?></p>
                
                <h4 class="text-xs font-bold text-gray-600 mb-1">Address</h4>
                <p class="text-sm text-gray-700 bg-gray-50 p-2 rounded border border-gray-100">
                    <?php echo nl2br(htmlspecialchars($order['address'])); ?>
                </p>
                
                <div class="mt-4 pt-3 border-t">
                    <span class="text-xs font-medium text-gray-500">Total Amount</span>
                    <p class="text-lg font-bold text-orange-600 mt-1">$<?php echo number_format($order['total_amount'], 2); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updateStatus() {
    const status = document.getElementById('statusSelect').value;
    const formData = new FormData();
    formData.append('action', 'update_order_status');
    formData.append('id', <?php echo $id; ?>);
    formData.append('status', status);

    fetch('ajax_admin.php', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            alert('Status updated successfully');
            location.reload();
        } else alert('Failed to update status');
    });
}
</script>

<?php require_once 'common/bottom.php'; ?>
