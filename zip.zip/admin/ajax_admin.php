<?php
require_once '../common/config.php';
session_start();
header('Content-Type: application/json');

if (!is_admin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = isset($_POST['action']) ? sanitize_input($_POST['action']) : '';

if ($action == 'add_category') {
    $name = sanitize_input($_POST['name']);
    $image = 'default.png';
    // Simplified file upload logic
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/' . $image);
    }
    $stmt = $conn->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
    $stmt->bind_param("ss", $name, $image);
    if($stmt->execute()) echo json_encode(['success' => true]);
    else echo json_encode(['success' => false, 'message' => 'Failed']);

} elseif ($action == 'delete_category') {
    $id = (int)$_POST['id'];
    $conn->query("DELETE FROM categories WHERE id=$id");
    echo json_encode(['success' => true]);

} elseif ($action == 'add_product') {
    $cat_id = (int)$_POST['category_id'];
    $name = sanitize_input($_POST['name']);
    $desc = sanitize_input($_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    
    $image = 'default.png';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        if(!is_dir('../uploads')) mkdir('../uploads');
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/' . $image);
    }
    
    $stmt = $conn->prepare("INSERT INTO products (category_id, name, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdis", $cat_id, $name, $desc, $price, $stock, $image);
    if($stmt->execute()) echo json_encode(['success' => true]);
    else echo json_encode(['success' => false, 'message' => 'Failed to add product.']);

} elseif ($action == 'delete_product') {
    $id = (int)$_POST['id'];
    $conn->query("DELETE FROM products WHERE id=$id");
    echo json_encode(['success' => true]);

} elseif ($action == 'update_order_status') {
    $id = (int)$_POST['id'];
    $status = sanitize_input($_POST['status']);
    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    if($stmt->execute()) echo json_encode(['success' => true]);
    else echo json_encode(['success' => false]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>
