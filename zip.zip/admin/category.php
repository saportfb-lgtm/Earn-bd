<?php
require_once '../common/config.php';
session_start();
if (!is_admin()) { header("Location: login.php"); exit; }
require_once 'common/header.php';
require_once 'common/sidebar.php';

$res = $conn->query("SELECT * FROM categories ORDER BY id DESC");
?>

<div class="px-4 py-6 md:px-8">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Categories</h1>
        <button onclick="document.getElementById('addModal').classList.remove('hidden')" class="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-black transition shadow-md">
            <i class="fa-solid fa-plus"></i> Add
        </button>
    </div>

    <!-- List -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-50 text-gray-500 uppercase text-xs">
                    <tr>
                        <th class="px-4 py-3">ID</th>
                        <th class="px-4 py-3">Image</th>
                        <th class="px-4 py-3">Name</th>
                        <th class="px-4 py-3 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php while($row = $res->fetch_assoc()): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-4 py-3 font-medium text-gray-900">#<?php echo $row['id']; ?></td>
                        <td class="px-4 py-3">
                            <img src="../uploads/<?php echo $row['image']; ?>" class="w-10 h-10 rounded shadow-sm object-cover" onerror="this.src='https://via.placeholder.com/40'">
                        </td>
                        <td class="px-4 py-3 font-semibold text-gray-800"><?php echo $row['name']; ?></td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <button onclick="deleteCat(<?php echo $row['id']; ?>)" class="text-red-500 hover:text-red-700 bg-red-50 px-2 py-1 rounded">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div id="addModal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden">
        <div class="flex justify-between items-center p-4 border-b">
            <h3 class="font-bold text-gray-800">Add Category</h3>
            <button onclick="document.getElementById('addModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600"><i class="fa-solid fa-times"></i></button>
        </div>
        <form id="addForm" onsubmit="addCat(event)" class="p-4 space-y-4">
            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Name</label>
                <input type="text" name="name" required class="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-gray-800">
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Image</label>
                <input type="file" name="image" class="w-full text-sm">
            </div>
            <button type="submit" class="w-full bg-gray-900 text-white rounded-lg py-2.5 font-bold shadow hover:bg-black transition">Save Category</button>
        </form>
    </div>
</div>

<script>
function addCat(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    formData.append('action', 'add_category');
    fetch('ajax_admin.php', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) location.reload();
        else alert(data.message);
    });
}
function deleteCat(id) {
    if(confirm("Delete this category?")) {
        const formData = new FormData();
        formData.append('action', 'delete_category');
        formData.append('id', id);
        fetch('ajax_admin.php', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => { if(data.success) location.reload(); });
    }
}
</script>

<?php require_once 'common/bottom.php'; ?>
