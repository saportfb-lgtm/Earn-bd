<!-- Admin Sidebar -->
<div id="admin-sidebar" class="fixed inset-y-0 left-0 w-64 bg-gray-900 text-white shadow-2xl z-50 transform -translate-x-full md:translate-x-0 md:relative transition-transform duration-300 ease-in-out flex flex-col">
    <div class="p-5 flex items-center justify-between border-b border-gray-800">
        <h2 class="text-xl font-bold text-orange-500">Ahox Bazar</h2>
        <button onclick="document.getElementById('admin-sidebar').classList.add('-translate-x-full')" class="text-gray-400 text-2xl md:hidden">
            <i class="fa-solid fa-times"></i>
        </button>
    </div>
    <div class="px-2 py-4 flex-1 overflow-y-auto">
        <ul class="space-y-1 text-sm font-medium pr-2">
            <li>
                <a href="index.php" class="flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'bg-gray-800 text-white' : ''; ?>">
                    <i class="fa-solid fa-gauge-high w-6 text-center mr-2"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="category.php" class="flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white <?php echo basename($_SERVER['PHP_SELF']) == 'category.php' ? 'bg-gray-800 text-white' : ''; ?>">
                    <i class="fa-solid fa-tags w-6 text-center mr-2"></i> Categories
                </a>
            </li>
            <li>
                <a href="product.php" class="flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white <?php echo basename($_SERVER['PHP_SELF']) == 'product.php' ? 'bg-gray-800 text-white' : ''; ?>">
                    <i class="fa-solid fa-box w-6 text-center mr-2"></i> Products
                </a>
            </li>
            <li>
                <a href="order.php" class="flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white <?php echo in_array(basename($_SERVER['PHP_SELF']), ['order.php', 'order_detail.php']) ? 'bg-gray-800 text-white' : ''; ?>">
                    <i class="fa-solid fa-shopping-cart w-6 text-center mr-2"></i> Orders
                </a>
            </li>
            <li>
                <a href="user.php" class="flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white <?php echo basename($_SERVER['PHP_SELF']) == 'user.php' ? 'bg-gray-800 text-white' : ''; ?>">
                    <i class="fa-solid fa-users w-6 text-center mr-2"></i> Users
                </a>
            </li>
            <li>
                <a href="setting.php" class="flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white <?php echo basename($_SERVER['PHP_SELF']) == 'setting.php' ? 'bg-gray-800 text-white' : ''; ?>">
                    <i class="fa-solid fa-cog w-6 text-center mr-2"></i> Settings
                </a>
            </li>
        </ul>
    </div>
    <div class="px-4 py-4 border-t border-gray-800">
        <a href="logout.php" class="flex items-center px-4 py-3 text-red-400 rounded-lg hover:bg-gray-800">
            <i class="fa-solid fa-sign-out-alt w-6 text-center mr-2"></i> Logout
        </a>
    </div>
</div>
<!-- Main Content Wrapper Starts Here -->
<div class="flex-1 overflow-x-hidden relative flex flex-col">
