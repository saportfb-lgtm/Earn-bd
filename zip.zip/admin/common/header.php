<?php
// admin/common/header.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Ahox Bazar - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f3f4f6; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 antialiased font-sans flex md:flex-row flex-col min-h-screen">

<!-- Mobile admin header -->
<header class="bg-gray-900 text-white shadow-sm sticky top-0 z-40 w-full md:hidden">
    <div class="flex items-center justify-between px-4 py-3">
        <div class="flex items-center gap-3">
            <button onclick="document.getElementById('admin-sidebar').classList.toggle('-translate-x-full')" class="text-white focus:outline-none">
                <i class="fa-solid fa-bars text-xl"></i>
            </button>
            <span class="text-lg font-bold tracking-tight">Admin Panel</span>
        </div>
    </div>
</header>
