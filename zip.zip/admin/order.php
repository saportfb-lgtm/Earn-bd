<?php
require_once '../common/config.php';
session_start();
if (!is_admin()) { header("Location: login.php"); exit; }
require_once 'common/header.php';
require_once 'common/sidebar.php';

$res = $conn->query("SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.id DESC");
?>

<div class="px-4 py-6 md:px-8">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Orders</h1>
    </div>

    <!-- List -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-50 text-gray-500 uppercase text-xs">
                    <tr>
                        <th class="px-4 py-3">Order ID</th>
                        <th class="px-4 py-3">Customer</th>
                        <th class="px-4 py-3">Amount</th>
                        <th class="px-4 py-3">Status</th>
                        <th class="px-4 py-3">Date</th>
                        <th class="px-4 py-3 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php while($row = $res->fetch_assoc()): ?>
                    <?php
                        $sc = [
                            'Placed' => 'bg-blue-100 text-blue-700',
                            'Dispatched' => 'bg-orange-100 text-orange-700',
                            'Delivered' => 'bg-green-100 text-green-700',
                            'Cancelled' => 'bg-red-100 text-red-700',
                        ][$row['status']];
                    ?>
                    <tr class="hover:bg-gray-50 transition cursor-pointer" onclick="window.location.href='order_detail.php?id=<?php echo $row['id']; ?>'">
                        <td class="px-4 py-3 font-bold text-gray-900">#<?php echo $row['id']; ?></td>
                        <td class="px-4 py-3 font-semibold text-gray-800"><?php echo $row['name']; ?></td>
                        <td class="px-4 py-3 font-bold text-gray-900">$<?php echo number_format($row['total_amount'], 2); ?></td>
                        <td class="px-4 py-3 shrink-0">
                            <span class="px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider <?php echo $sc; ?>">
                                <?php echo $row['status']; ?>
                            </span>
                        </td>
                        <td class="px-4 py-3 text-gray-500 text-xs"><?php echo date("d M Y H:i", strtotime($row['created_at'])); ?></td>
                        <td class="px-4 py-3 text-right">
                            <button class="text-gray-400 hover:text-gray-600 bg-gray-50 px-2 py-1 rounded">
                                <i class="fa-solid fa-chevron-right"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>
