<?php
require_once '../common/config.php';
session_start();
if (!is_admin()) { header("Location: login.php"); exit; }
require_once 'common/header.php';
require_once 'common/sidebar.php';

$res = $conn->query("SELECT * FROM users ORDER BY id DESC");
?>

<div class="px-4 py-6 md:px-8">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Users</h1>
    </div>

    <!-- List -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-50 text-gray-500 uppercase text-xs">
                    <tr>
                        <th class="px-4 py-3">ID</th>
                        <th class="px-4 py-3">Name</th>
                        <th class="px-4 py-3">Email</th>
                        <th class="px-4 py-3">Phone</th>
                        <th class="px-4 py-3">Joined Date</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php while($row = $res->fetch_assoc()): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-4 py-3 font-medium text-gray-900">#<?php echo $row['id']; ?></td>
                        <td class="px-4 py-3 font-semibold text-gray-800"><?php echo $row['name']; ?></td>
                        <td class="px-4 py-3 text-gray-600"><?php echo $row['email']; ?></td>
                        <td class="px-4 py-3 text-gray-600"><?php echo $row['phone']; ?></td>
                        <td class="px-4 py-3 text-gray-500 text-xs"><?php echo date("d M Y", strtotime($row['created_at'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>
