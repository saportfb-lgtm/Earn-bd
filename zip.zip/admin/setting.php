<?php
require_once '../common/config.php';
session_start();
if (!is_admin()) { header("Location: login.php"); exit; }

$msg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $password = $_POST['password'];
    $new_password = $_POST['new_password'];
    
    $stmt = $conn->prepare("SELECT password FROM admin WHERE id=?");
    $stmt->bind_param("i", $_SESSION['admin_id']);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();
    
    if(password_verify($password, $admin['password'])) {
        $hash = password_hash($new_password, PASSWORD_BCRYPT);
        $up = $conn->prepare("UPDATE admin SET password=? WHERE id=?");
        $up->bind_param("si", $hash, $_SESSION['admin_id']);
        if($up->execute()) $msg = "Password updated successfully.";
    } else {
        $msg = "Incorrect current password.";
    }
}

require_once 'common/header.php';
require_once 'common/sidebar.php';
?>

<div class="px-4 py-6 md:px-8">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Settings</h1>
    </div>

    <?php if($msg): ?>
        <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded relative mb-4 text-sm" role="alert">
            <span class="block sm:inline"><?php echo $msg; ?></span>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 max-w-lg">
        <h3 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Change Password</h3>
        
        <form method="POST" action="setting.php" class="space-y-4">
            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Current Password</label>
                <div class="relative">
                    <i class="fa-solid fa-lock absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <input type="password" name="password" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-gray-800">
                </div>
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">New Password</label>
                <div class="relative">
                    <i class="fa-solid fa-key absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <input type="password" name="new_password" required class="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-gray-800">
                </div>
            </div>
            <button type="submit" class="bg-gray-900 text-white rounded-lg px-6 py-2.5 font-bold shadow hover:bg-black transition">Update Password</button>
        </form>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>
