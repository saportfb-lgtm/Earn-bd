<?php
require_once '../common/config.php';
session_start();
if (!is_admin()) { header("Location: login.php"); exit; }
require_once 'common/header.php';
require_once 'common/sidebar.php';

// Stats queries
$users_count = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$orders_count = $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
$rev_res = $conn->query("SELECT SUM(total_amount) as s FROM orders WHERE status='Delivered'");
$revenue = $rev_res ? $rev_res->fetch_assoc()['s'] : 0;
$revenue = $revenue ?: 0;
$prods_count = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$canc_count = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status='Cancelled'")->fetch_assoc()['c'];
$disp_count = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status='Dispatched'")->fetch_assoc()['c'];
?>

<div class="px-4 py-6 md:px-8">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
    </div>

    <!-- Quick Stats Grid -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <!-- Revenue -->
        <div class="bg-gradient-to-br from-green-400 to-green-600 rounded-2xl p-4 text-white shadow-lg shadow-green-200">
            <div class="flex justify-between items-start mb-2">
                <div class="bg-white/20 p-2 rounded-lg"><i class="fa-solid fa-dollar-sign"></i></div>
            </div>
            <h3 class="text-2xl font-bold font-mono">$<?php echo number_format($revenue, 2); ?></h3>
            <p class="text-xs font-semibold opacity-90 mt-1">Total Revenue</p>
        </div>
        
        <!-- Orders -->
        <div class="bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl p-4 text-white shadow-lg shadow-orange-200">
            <div class="flex justify-between items-start mb-2">
                <div class="bg-white/20 p-2 rounded-lg"><i class="fa-solid fa-cart-shopping"></i></div>
            </div>
            <h3 class="text-2xl font-bold font-mono"><?php echo $orders_count; ?></h3>
            <p class="text-xs font-semibold opacity-90 mt-1">Total Orders</p>
        </div>
        
        <!-- Users -->
        <div class="bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl p-4 text-white shadow-lg shadow-blue-200">
            <div class="flex justify-between items-start mb-2">
                <div class="bg-white/20 p-2 rounded-lg"><i class="fa-solid fa-users"></i></div>
            </div>
            <h3 class="text-2xl font-bold font-mono"><?php echo $users_count; ?></h3>
            <p class="text-xs font-semibold opacity-90 mt-1">Total Users</p>
        </div>
        
        <!-- Products -->
        <div class="bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl p-4 text-white shadow-lg shadow-purple-200">
            <div class="flex justify-between items-start mb-2">
                <div class="bg-white/20 p-2 rounded-lg"><i class="fa-solid fa-box-open"></i></div>
            </div>
            <h3 class="text-2xl font-bold font-mono"><?php echo $prods_count; ?></h3>
            <p class="text-xs font-semibold opacity-90 mt-1">Active Products</p>
        </div>

        <div class="bg-white border rounded-2xl p-4 shadow-sm">
            <div class="flex justify-between items-start mb-2">
                <div class="text-red-500 bg-red-50 p-2 rounded-lg"><i class="fa-solid fa-ban"></i></div>
            </div>
            <h3 class="text-xl font-bold text-gray-800 font-mono"><?php echo $canc_count; ?></h3>
            <p class="text-xs text-gray-500 font-medium mt-1">Cancellations</p>
        </div>

        <div class="bg-white border rounded-2xl p-4 shadow-sm">
            <div class="flex justify-between items-start mb-2">
                <div class="text-blue-500 bg-blue-50 p-2 rounded-lg"><i class="fa-solid fa-truck-fast"></i></div>
            </div>
            <h3 class="text-xl font-bold text-gray-800 font-mono"><?php echo $disp_count; ?></h3>
            <p class="text-xs text-gray-500 font-medium mt-1">Dispatching</p>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-6">
        <h3 class="text-sm font-bold text-gray-800 mb-4 uppercase tracking-wider">Quick Actions</h3>
        <div class="flex flex-wrap gap-3">
            <a href="product.php" class="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 transition"><i class="fa-solid fa-plus mr-1"></i> Add Product</a>
            <a href="category.php" class="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 transition"><i class="fa-solid fa-plus mr-1"></i> Add Category</a>
            <a href="order.php" class="bg-gray-100 text-gray-800 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition"><i class="fa-solid fa-eye mr-1"></i> View Orders</a>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>
