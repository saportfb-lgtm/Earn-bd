<!-- Mobile Sidebar -->
<div id="sidebar" class="fixed inset-y-0 left-0 w-64 bg-white shadow-2xl z-50 transform -translate-x-full transition-transform duration-300 ease-in-out">
    <div class="p-5 flex items-center justify-between border-b">
        <h2 class="text-xl font-bold text-orange-600">Menu</h2>
        <button onclick="document.getElementById('sidebar').classList.add('-translate-x-full')" class="text-gray-500 text-2xl">
            <i class="fa-solid fa-times"></i>
        </button>
    </div>
    <div class="px-2 py-4">
        <ul class="space-y-1 text-sm font-medium">
            <li>
                <a href="index.php" class="flex items-center px-3 py-3 text-gray-700 rounded-lg hover:bg-orange-50 hover:text-orange-600">
                    <i class="fa-solid fa-home w-6 text-center mr-2"></i> Home
                </a>
            </li>
            <li>
                <a href="product.php" class="flex items-center px-3 py-3 text-gray-700 rounded-lg hover:bg-orange-50 hover:text-orange-600">
                    <i class="fa-solid fa-box w-6 text-center mr-2"></i> All Products
                </a>
            </li>
            <li>
                <a href="cart.php" class="flex items-center px-3 py-3 text-gray-700 rounded-lg hover:bg-orange-50 hover:text-orange-600">
                    <i class="fa-solid fa-shopping-cart w-6 text-center mr-2"></i> My Cart
                </a>
            </li>
            <li>
                <a href="order.php" class="flex items-center px-3 py-3 text-gray-700 rounded-lg hover:bg-orange-50 hover:text-orange-600">
                    <i class="fa-solid fa-clipboard-list w-6 text-center mr-2"></i> My Orders
                </a>
            </li>
            <li class="pt-4 mt-4 border-t border-gray-100">
                <?php if(is_logged_in()): ?>
                    <a href="profile.php" class="flex items-center px-3 py-3 text-gray-700 rounded-lg hover:bg-orange-50 hover:text-orange-600">
                        <i class="fa-solid fa-user w-6 text-center mr-2"></i> My Profile
                    </a>
                    <a href="#" onclick="logoutUser()" class="flex items-center px-3 py-3 text-red-600 rounded-lg hover:bg-red-50 mt-1">
                        <i class="fa-solid fa-sign-out-alt w-6 text-center mr-2"></i> Logout
                    </a>
                <?php else: ?>
                    <a href="login.php" class="flex items-center px-3 py-3 text-gray-700 rounded-lg hover:bg-orange-50 hover:text-orange-600">
                        <i class="fa-solid fa-sign-in-alt w-6 text-center mr-2"></i> Login / Sign Up
                    </a>
                <?php endif; ?>
            </li>
        </ul>
    </div>
</div>

<!-- Overlay -->
<div id="sidebarOverlay" onclick="document.getElementById('sidebar').classList.add('-translate-x-full')" class="fixed inset-0 bg-black/50 z-40 hidden"></div>

<script>
    // Watch for sidebar classes to toggle overlay
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    // Quick observer for sidebar classes
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.attributeName === "class") {
                const classList = mutation.target.className;
                if(classList.includes('-translate-x-full')) {
                    overlay.classList.add('hidden');
                } else {
                    overlay.classList.remove('hidden');
                }
            }
        });
    });
    observer.observe(sidebar, { attributes: true });

    function logoutUser() {
        const formData = new FormData();
        formData.append('action', 'logout');
        fetch('ajax_auth.php', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'index.php';
            }
        });
    }
</script>
