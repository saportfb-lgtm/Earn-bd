<!-- Bottom Navigation -->
<nav class="fixed bottom-0 w-full bg-white border-t rounded-t-xl pb-safe shadow-[0_-2px_10px_rgba(0,0,0,0.05)] z-30">
    <div class="flex justify-around items-center h-16">
        <a href="index.php" class="flex flex-col items-center justify-center w-full h-full text-gray-500 hover:text-orange-600 <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'text-orange-600' : ''; ?>">
            <i class="fa-solid fa-home text-lg mb-1"></i>
            <span class="text-[10px] font-medium">Home</span>
        </a>
        <a href="product.php" class="flex flex-col items-center justify-center w-full h-full text-gray-500 hover:text-orange-600 <?php echo (basename($_SERVER['PHP_SELF']) == 'product.php') ? 'text-orange-600' : ''; ?>">
            <i class="fa-solid fa-list text-lg mb-1"></i>
            <span class="text-[10px] font-medium">Categories</span>
        </a>
        <!-- Cart button slightly elevated -->
        <div class="w-full flex justify-center relative -top-3">
            <a href="cart.php" class="flex items-center justify-center w-14 h-14 bg-orange-600 text-white rounded-full shadow-lg shadow-orange-200 border-4 border-gray-50">
                <i class="fa-solid fa-shopping-cart text-xl relative">
                    <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <span class="absolute -top-1 -right-2 bg-red-500 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-bold">
                        <?php echo count($_SESSION['cart']); ?>
                    </span>
                    <?php endif; ?>
                </i>
            </a>
        </div>
        <a href="order.php" class="flex flex-col items-center justify-center w-full h-full text-gray-500 hover:text-orange-600 <?php echo (basename($_SERVER['PHP_SELF']) == 'order.php') ? 'text-orange-600' : ''; ?>">
            <i class="fa-solid fa-box-open text-lg mb-1"></i>
            <span class="text-[10px] font-medium">Orders</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center justify-center w-full h-full text-gray-500 hover:text-orange-600 <?php echo (basename($_SERVER['PHP_SELF']) == 'profile.php' || basename($_SERVER['PHP_SELF']) == 'login.php') ? 'text-orange-600' : ''; ?>">
            <i class="fa-solid fa-user text-lg mb-1"></i>
            <span class="text-[10px] font-medium">Profile</span>
        </a>
    </div>
</nav>

<!-- JavaScript to add padding bottom for iPhone safe area if needed -->
<style>
    .pb-safe { padding-bottom: env(safe-area-inset-bottom); }
</style>
</body>
</html>
