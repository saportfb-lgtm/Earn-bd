<?php 
// common/header.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Ahox Bazar</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Disable text selection and basic touch callouts */
        body {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-tap-highlight-color: transparent;
            -webkit-touch-callout: none;
            background-color: #f3f4f6; /* min-h-screen bg-gray-100 */
        }
        
        /* Hide scrollbar for horizontal scrolling elements */
        .hide-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .hide-scrollbar {
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;  /* Firefox */
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 antialiased pb-20 overflow-x-hidden font-sans">

    <!-- Top Navigation -->
    <header class="bg-white shadow-sm sticky top-0 z-40 w-full">
        <div class="flex items-center justify-between px-4 py-3">
            <div class="flex items-center gap-3">
                <button onclick="document.getElementById('sidebar').classList.remove('-translate-x-full')" class="text-gray-600 focus:outline-none">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
                <a href="index.php" class="text-xl font-bold tracking-tight text-orange-600">Ahox Bazar</a>
            </div>
            <div class="flex items-center gap-4 text-gray-600">
                <a href="cart.php" class="relative">
                    <i class="fa-solid fa-shopping-bag text-xl"></i>
                    <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <span class="absolute -top-1 -right-2 bg-orange-600 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-bold">
                        <?php echo count($_SESSION['cart']); ?>
                    </span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
        <!-- Search Bar -->
        <div class="px-4 pb-3">
            <div class="relative w-full">
                <i class="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="text" placeholder="Search for products, brands..." 
                       class="w-full bg-gray-100 text-sm rounded-lg pl-10 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-orange-500">
            </div>
        </div>
    </header>

    <script>
        // Disable right-click
        document.addEventListener('contextmenu', event => event.preventDefault());

        // Disable standard zoom
        document.addEventListener('keydown', function(event) {
            if (event.ctrlKey && (event.key === '=' || event.key === '-' || event.key === '0')) {
                event.preventDefault();
            }
        });
        document.addEventListener('wheel', function(event) {
            if (event.ctrlKey) {
                event.preventDefault();
            }
        }, { passive: false });
    </script>
