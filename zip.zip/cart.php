<?php
require_once 'common/config.php';
require_once 'common/header.php';
require_once 'common/sidebar.php';

$cart_items = [];
$total_price = 0;

if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $sql = "SELECT * FROM products WHERE id IN ($ids)";
    $result = $conn->query($sql);
    if ($result) {
        while($row = $result->fetch_assoc()) {
            $qty = $_SESSION['cart'][$row['id']];
            $row['qty'] = $qty;
            $row['subtotal'] = $row['price'] * $qty;
            $total_price += $row['subtotal'];
            $cart_items[] = $row;
        }
    }
}
?>

<div class="px-4 py-4 min-h-[80vh] flex flex-col">
    <h2 class="text-xl font-bold text-gray-800 mb-4">Shopping Cart</h2>
    
    <?php if(empty($cart_items)): ?>
        <div class="flex-1 flex flex-col items-center justify-center text-center">
            <i class="fa-solid fa-cart-arrow-down text-6xl text-gray-300 mb-4"></i>
            <h3 class="text-lg font-bold text-gray-700 mb-2">Your cart is empty</h3>
            <p class="text-sm text-gray-500 mb-6">Looks like you haven't added anything to your cart yet.</p>
            <a href="index.php" class="bg-orange-600 text-white px-6 py-2.5 rounded-full font-semibold shadow-md active:bg-orange-700">Start Shopping</a>
        </div>
    <?php else: ?>
        <div class="flex-1 space-y-4">
            <?php foreach($cart_items as $item): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-3 flex gap-3 relative" id="cart-item-<?php echo $item['id']; ?>">
                <button onclick="removeFromCart(<?php echo $item['id']; ?>)" class="absolute top-2 right-2 text-red-500 hover:text-red-700 p-1">
                    <i class="fa-solid fa-trash-alt"></i>
                </button>
                <div class="w-20 h-20 bg-gray-50 rounded-lg flex-shrink-0 flex items-center justify-center overflow-hidden">
                    <img src="uploads/<?php echo $item['image']; ?>" onerror="this.src='https://via.placeholder.com/80?text=Item'" alt="<?php echo $item['name']; ?>" class="max-w-full max-h-full object-contain">
                </div>
                <div class="flex flex-col flex-1 py-1 pr-4">
                    <h4 class="text-sm font-semibold text-gray-800 line-clamp-1 mb-1"><?php echo $item['name']; ?></h4>
                    <span class="text-xs text-gray-500 mb-2">Price: $<?php echo number_format($item['price'], 2); ?></span>
                    <div class="mt-auto flex items-center justify-between">
                        <span class="text-orange-600 font-bold">$<span id="subtotal-<?php echo $item['id']; ?>"><?php echo number_format($item['subtotal'], 2); ?></span></span>
                        
                        <!-- Quantity Control -->
                        <div class="flex items-center bg-gray-100 rounded-full border border-gray-200 shadow-inner px-1">
                            <button onclick="updateQty(<?php echo $item['id']; ?>, -1)" class="w-6 h-6 flex items-center justify-center text-gray-600 font-bold active:bg-gray-200 rounded-full">-</button>
                            <input type="text" id="qty-<?php echo $item['id']; ?>" value="<?php echo $item['qty']; ?>" readonly class="w-8 text-center text-sm bg-transparent font-medium focus:outline-none">
                            <button onclick="updateQty(<?php echo $item['id']; ?>, 1)" class="w-6 h-6 flex items-center justify-center text-gray-600 font-bold active:bg-gray-200 rounded-full">+</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Checkout Bottom Area -->
        <div class="mt-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div class="flex justify-between items-center mb-2">
                <span class="text-sm text-gray-600">Subtotal</span>
                <span class="font-semibold text-gray-800">$<span id="cart-total"><?php echo number_format($total_price, 2); ?></span></span>
            </div>
            <div class="flex justify-between items-center mb-4">
                <span class="text-sm text-gray-600">Shipping</span>
                <span class="font-semibold text-gray-800 text-sm">Free</span>
            </div>
            <hr class="mb-4">
            <div class="flex justify-between items-center mb-4 text-lg">
                <span class="font-bold text-gray-800">Total</span>
                <span class="font-bold text-orange-600">$<span id="cart-final-total"><?php echo number_format($total_price, 2); ?></span></span>
            </div>
            <a href="checkout.php" class="block w-full bg-orange-600 text-white text-center py-3 rounded-xl font-bold shadow-md shadow-orange-200 active:bg-orange-700">Proceed to Checkout</a>
        </div>
    <?php endif; ?>
</div>

<script>
function updateQty(productId, change) {
    let qtyInput = document.getElementById('qty-' + productId);
    let currentQty = parseInt(qtyInput.value);
    let newQty = currentQty + change;
    if (newQty < 1) newQty = 1;

    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('product_id', productId);
    formData.append('qty', newQty);

    fetch('ajax_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            location.reload(); // Reload to recalculate totals safely
        }
    });
}

function removeFromCart(productId) {
    if(confirm('Remove this item?')) {
        const formData = new FormData();
        formData.append('action', 'remove');
        formData.append('product_id', productId);

        fetch('ajax_cart.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                location.reload();
            }
        });
    }
}
</script>

<?php require_once 'common/bottom.php'; ?>
