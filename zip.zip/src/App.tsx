/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function App() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6 text-center">
      <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md w-full">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Ahox Bazar (PHP Version)</h1>
        <p className="text-gray-600 mb-6">
          Your PHP/MySQL E-commerce application files are being generated in the project workspace!
        </p>
        <p className="text-gray-600 text-sm mb-6">
          Note: This live preview environment is built on Node.js and does not natively execute PHP or MySQL. 
          Once the generation is complete, you can download all the files by clicking the <strong>Export</strong> button in the settings menu (or Export to ZIP) and run them on your local Apache/MySQL server (like XAMPP/WAMP) or your hosting provider.
        </p>
      </div>
    </div>
  );
}
